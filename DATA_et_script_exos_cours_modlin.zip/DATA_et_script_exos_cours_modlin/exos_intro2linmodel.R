dtot <- read.table("DATA/Milne1950.txt", header = TRUE)
str(dtot)

# replacement of 0% humidity by 10% 
# as in the paper Wongnak et al. 2022
dtot$rel_hum[dtot$rel_hum == 0] <- 10

# add of the log10 tranformed survival time
dtot$log10_surv_time <- log10(dtot$surv_time)

ggplot(data = dtot, aes(x = rel_hum, y = surv_time, 
       col = temperature)) + geom_point()
ggplot(data = dtot, aes(x = rel_hum, y = log10_surv_time, 
       col = temperature)) + geom_point()
ggplot(data = dtot, aes(x = rel_hum, y = log10_surv_time, 
       col = temperature)) + geom_jitter(width = 2)

###
dRH50 <- subset(dtot, rel_hum == 50)
plot(log10_surv_time ~ temperature, data = dRH50, pch = 16)

(m <- lm(log10_surv_time ~ temperature, data = dRH50))
summary(m)
summary(m)$coefficients

plot(log10_surv_time ~ temperature, data = dRH50, pch = 16)
abline(m)

plot(residuals(m) ~ fitted(m))
qqnorm(residuals(m))

## Code to write by yourself to answer the questions ##





#######################################################
coef(m)
confint(m)

data4pred <- data.frame(temperature = 10)
predict(m, interval = "confidence", newdata = data4pred)

predict(m, interval = "prediction", newdata = data4pred)

summary(m)

## Code to write by yourself to answer the questions ##





#######################################################

dhum <- subset(dtot, rel_hum > 10)
ggplot(data = dhum, aes(x = rel_hum, y = log10_surv_time,
col = temperature)) + geom_jitter(width = 2)

(mm <- lm(log10_surv_time ~ rel_hum + temperature, data = dhum))

summary(mm)

summary(mm)$coefficients

mm <- lm(log10_surv_time ~ rel_hum + temperature, data = dhum)
mrel_hum <- lm(log10_surv_time ~ rel_hum, data = dhum)
anova(mm, mrel_hum)

mm <- lm(log10_surv_time ~ rel_hum + temperature, data = dhum)
mtemperature <- lm(log10_surv_time ~ temperature, data = dhum)
anova(mm, mtemperature)

plot(residuals(mm) ~ fitted(mm))
qqnorm(residuals(mm))
par(mar = c(4, 4, 0, 0), mfrow = c(1,2))
plot(residuals(mm) ~ rel_hum, data = dhum)
plot(residuals(mm) ~ temperature, data = dhum)

ggplot(data = dtot, aes(x = rel_hum, y = log10_surv_time,
col = temperature)) + geom_jitter(width = 2)

###
(mm2 <- lm(log10_surv_time ~ rel_hum + I(rel_hum^2) +
                   temperature, data = dhum))

## Code to write by yourself to answer the questions ##





#######################################################

# Define the qualitative variable
dtot$rel_humF <- as.factor(dtot$rel_hum)
levels(dtot$rel_humF)

plot(log10_surv_time ~ rel_humF, data = dtot)

(manova1 <- lm(log10_surv_time ~ rel_humF, data = dtot))

anova(manova1)

par(mar = c(4, 4, 2, 2), mfrow = c(1,2))
plot(residuals(manova1) ~ fitted(manova1))
qqnorm(residuals(manova1))

# Observed means
tapply(dtot$log10_surv_time, dtot$rel_humF, mean)

# Coefficients with their 95% confidence intervals
coef(manova1)
confint(manova1)

library(sjPlot)
plot_model(manova1, type = "est")

###
dtot$temperatureF <- as.factor(ifelse(dtot$temperature < 15,                                      "cold", "hot"))
# Look at the experimental design
xtabs(data = dtot, ~ rel_humF + temperatureF)

ggplot(data = dtot, aes(x = rel_humF, y = log10_surv_time, 
        col = temperatureF)) + geom_point() +
 stat_summary(fun = mean, geom = "line", aes(group = temperatureF))
within(dtot, interaction.plot(rel_humF, temperatureF, log10_surv_time))
within(dtot, interaction.plot(temperatureF, rel_humF, log10_surv_time))

(manova2 <- lm(log10_surv_time ~ rel_humF + temperatureF, 
               data = dtot))

plot_model(manova2)

(manova2int <- lm(log10_surv_time ~ rel_humF + temperatureF +
                    rel_humF:temperatureF, data = dtot))

plot_model(manova2int)

anova(manova2int, manova2)

###
dhum$temperatureF <- as.factor(ifelse(dhum$temperature < 15, 
                                      "cold", "hot"))

ggplot(data = dhum, aes(x = rel_hum, y = log10_surv_time, 
       col = temperatureF)) + geom_jitter(width = 1)


(mancova <- lm(log10_surv_time ~ rel_hum + temperatureF,
                  data = dhum))

plot_model(mancova)
plot_model(mancova, type = "std2")

(mancovaint <- lm(log10_surv_time ~ rel_hum + temperatureF +
                   rel_hum:temperatureF, data = dhum))

plot_model(mancovaint, type = "std2")

## Code to write by yourself to answer the questions ##





#######################################################
